public class Main {
  public static void main(String[] a)
  {
    Turtle bob = new Turtle();
    //Look at https://docs.oracle.com/javase/7/docs/api/java/awt/Color.html for different colours
    Turtle.bgcolor("lightblue");
    bob.penColor("red");
    bob.width(10);

    //draw the body of the house
    bob.left(90);
    bob.forward(250);
    bob.left(90);
    bob.forward(250);
    bob.left(90);
    bob.forward(250);
    bob.left(90);
    bob.forward(250);
    //draw the door of the house
    bob.up();
    bob.setPosition(-140, 0);
    bob.down();
    bob.left(90);
    bob.forward(120);
    bob.left(90);
    bob.forward(60);
    bob.left(90);
    bob.forward(120);
    //draw the window of the house
    bob.up();
    bob.setPosition(-20, 160);
    bob.down();
    bob.left(180);
    bob.forward(70);
    bob.left(90);
    bob.forward(70);
    bob.left(90);
    bob.forward(70);
    bob.left(90);
    bob.forward(70);
    bob.up();
    bob.setPosition(-20, 195);
    bob.down();
    bob.left(180);
    bob.forward(70);
    bob.up();
    bob.setPosition(-55, 160);
    bob.down();
    bob.right(90);
    bob.forward(70);
    //draw the rooftop of the house
    bob.up();
    bob.setPosition(0, 250);
    bob.down();
    bob.right(90);
    bob.forward(20);
    bob.left(140);
    bob.forward(189);
    bob.left(80);
    bob.forward(189);
    bob.left(140);
    bob.forward(20);
    //draw the chimney of the house
    bob.up();
    bob.setPosition(15, 260);
    bob.down();
    bob.left(90);
    bob.forward(140);
    bob.left(90);
    bob.forward(70);
    bob.left(90);
    bob.forward(70);




    /*possible codes:
      bob.forward(distance)
      bob.backward(distance)
      bob.left(angle)
      bob.right(angle)

      bob.up()
      bob.down()

      bob.setDirection(angle)
      bob.home()
      bob.hide()
      bob.show()
      bob.face(x, y)
      bob.setPosition(x, y)

      bob.tilt(angle)
      bob.width(width)
      bob.penColor("colour")
      bob.bgcolor("colour")
      
      bob.stamp()
      bob.dot()
      bob.dot("colour")
      bob.dot("colour", dotsize)
    */
    
  }
}