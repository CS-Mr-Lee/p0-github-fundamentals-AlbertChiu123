public class Main {
  public static void main(String[] a)
  {
    Turtle bob = new Turtle();
    //Look at https://docs.oracle.com/javase/7/docs/api/java/awt/Color.html for different colours
    Turtle.bgcolor("lightblue");
    bob.penColor("blue");
    bob.width(10);
    //draw the face of the discord symbol
    bob.right(10);
    bob.forward(150);
    bob.left(80);
    bob.forward(40);
    bob.left(100);
    bob.forward(30);
    bob.right(90);
    bob.forward(15);
    bob.right(90);
    bob.forward(100);
    bob.left(10);
    bob.forward(100);
    bob.left(10);
    bob.forward(100);
    bob.right(90);
    bob.forward(15);
    bob.right(90);
    bob.forward(30);
    bob.left(90);
    bob.forward(40);
    bob.left(90);
    bob.forward(150);
    bob.left(80);
    bob.forward(100);
    bob.left(10);
    bob.forward(100);
    bob.left(20);
    bob.forward(100);
    bob.left(50);
    bob.forward(100);
    bob.left(90);
    bob.forward(30);
    bob.right(100);
    bob.forward(60);
    bob.left(20);
    bob.forward(100);
    bob.left(20);
    bob.forward(60);
    bob.right(100);
    bob.forward(30);
    bob.left(90);
    bob.forward(100);
    bob.left(50);
    bob.forward(100);
    bob.left(20);
    bob.forward(100);
    bob.left(10);
    bob.forward(100);
    //draw the eyes of the discord symbol
    bob.up();
    bob.setPosition(200, 150);
    bob.dot("blue", 100);
    bob.up();
    bob.setPosition(370, 150);
    bob.dot("blue", 100);
    //draw the outlayer of the discord symbol
    bob.up();
    bob.setPosition(-150, -200);
    bob.down();
    bob.left(180);
    bob.forward(650);
    bob.right(90);
    bob.forward(850);
    bob.right(90);
    bob.forward(700);
    bob.right(130);
    bob.forward(150);
    bob.left(150);
    bob.forward(50);
    bob.right(110);
    bob.forward(750);











    /*possible codes:
      bob.forward(distance)
      bob.backward(distance)
      bob.left(angle)
      bob.right(angle)

      bob.up()
      bob.down()

      bob.setDirection(angle)
      bob.home()
      bob.hide()
      bob.show()
      bob.face(x, y)
      bob.setPosition(x, y)

      bob.tilt(angle)
      bob.width(width)
      bob.penColor("colour")
      bob.bgcolor("colour")
      
      bob.stamp()
      bob.dot()
      bob.dot("colour")
      bob.dot("colour", dotsize)
    */
    
  }
}