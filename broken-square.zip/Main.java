public class Main {
  public static void main(String[] a)
  {
    Turtle bob = new Turtle();
    //Look at https://docs.oracle.com/javase/7/docs/api/java/awt/Color.html for different colours
    Turtle.bgcolor("lightblue");
    bob.penColor("red");
    bob.width(10);
    bob.left(90);
    bob.forward(30);
    bob.up();
    bob.forward(30);
    bob.down();
    bob.forward(50);
    bob.up();
    bob.forward(30);
    bob.down();
    bob.forward(30);
    bob.left(90);
    bob.forward(30);
    bob.up();
    bob.forward(30);
    bob.down();
    bob.forward(40);
    bob.up();
    bob.forward(40);
    bob.down();
    bob.forward(30);
    bob.left(90);
    bob.forward(20);
    bob.up();
    bob.forward(40);
    bob.down();
    bob.forward(50);
    bob.up();
    bob.forward(40);
    bob.down();
    bob.forward(20);
    bob.left(90);
    bob.forward(20);
    bob.up();
    bob.forward(40);
    bob.down();
    bob.forward(50);
    bob.up();
    bob.forward(40);
    bob.down();
    bob.forward(20);



    /*possible codes:
      bob.forward(distance)
      bob.backward(distance)
      bob.left(angle)
      bob.right(angle)

      bob.up()
      bob.down()

      bob.setDirection(angle)
      bob.home()
      bob.hide()
      bob.show()
      bob.face(x, y)
      bob.setPosition(x, y)

      bob.tilt(angle)
      bob.width(width)
      bob.penColor("colour")
      bob.bgcolor("colour")
      
      bob.stamp()
      bob.dot()
      bob.dot("colour")
      bob.dot("colour", dotsize)
    */
    
  }
}